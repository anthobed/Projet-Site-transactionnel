<template lang="html">
  <slot name="head"></slot>
  <slot name="main"></slot>
  <slot name="footer"></slot>
</template>
<script>
export default {
  name: "BaseCard",
  components: {},
  methods: {},
};
</script>
<style></style>
