<template>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
  <div class="bubble"></div>
</template>
<script></script>

<style scoped>
:root {
  --darkGrey: rgb(37, 37, 37);
  --lightGrey: rgb(221, 221, 221);
  --mediumGrey: rgb(130, 130, 130);
}

.bubble {
  display: flex;
  border-radius: 100%;
  opacity: 0.8;
  height: auto;
  position: fixed;
  z-index: 1;
}
.bubble:nth-child(1) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 63px;
  height: 63px;
  left: 26vw;
  bottom: 5vh;
  -webkit-animation: move1 infinite 14s;
  animation: move1 infinite 14s;
}
@-webkit-keyframes move1 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 1vh;
    transform: translate(24px, 0);
    opacity: 0;
  }
}
@keyframes move1 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 1vh;
    transform: translate(24px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(2) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 87px;
  height: 87px;
  left: 61vw;
  bottom: 76vh;
  -webkit-animation: move2 infinite 11s;
  animation: move2 infinite 11s;
}
@-webkit-keyframes move2 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 37vh;
    transform: translate(80px, 0);
    opacity: 0;
  }
}
@keyframes move2 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 37vh;
    transform: translate(80px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(3) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 82px;
  height: 82px;
  left: 35vw;
  bottom: 25vh;
  -webkit-animation: move3 infinite 6s;
  animation: move3 infinite 6s;
}
@-webkit-keyframes move3 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 13vh;
    transform: translate(178px, 0);
    opacity: 0;
  }
}
@keyframes move3 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 13vh;
    transform: translate(178px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(4) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 22px;
  height: 22px;
  left: 64vw;
  bottom: 67vh;
  -webkit-animation: move4 infinite 7s;
  animation: move4 infinite 7s;
}
@-webkit-keyframes move4 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 0vh;
    transform: translate(35px, 0);
    opacity: 0;
  }
}
@keyframes move4 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 0vh;
    transform: translate(35px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(5) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 69px;
  height: 69px;
  left: 36vw;
  bottom: 11vh;
  -webkit-animation: move5 infinite 8s;
  animation: move5 infinite 8s;
}
@-webkit-keyframes move5 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 72vh;
    transform: translate(184px, 0);
    opacity: 0;
  }
}
@keyframes move5 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 72vh;
    transform: translate(184px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(6) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 42px;
  height: 42px;
  left: 11vw;
  bottom: 13vh;
  -webkit-animation: move6 infinite 6s;
  animation: move6 infinite 6s;
}
@-webkit-keyframes move6 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 88vh;
    transform: translate(117px, 0);
    opacity: 0;
  }
}
@keyframes move6 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 88vh;
    transform: translate(117px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(7) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 18px;
  height: 18px;
  left: 12vw;
  bottom: 3vh;
  -webkit-animation: move7 infinite 7s;
  animation: move7 infinite 7s;
}
@-webkit-keyframes move7 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 96vh;
    transform: translate(76px, 0);
    opacity: 0;
  }
}
@keyframes move7 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 96vh;
    transform: translate(76px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(8) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 9px;
  height: 9px;
  left: 73vw;
  bottom: 75vh;
  -webkit-animation: move8 infinite 7s;
  animation: move8 infinite 7s;
}
@-webkit-keyframes move8 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 30vh;
    transform: translate(179px, 0);
    opacity: 0;
  }
}
@keyframes move8 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 30vh;
    transform: translate(179px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(9) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 93px;
  height: 93px;
  left: 28vw;
  bottom: 46vh;
  -webkit-animation: move9 infinite 15s;
  animation: move9 infinite 15s;
}
@-webkit-keyframes move9 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 41vh;
    transform: translate(-47px, 0);
    opacity: 0;
  }
}
@keyframes move9 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 41vh;
    transform: translate(-47px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(10) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 78px;
  height: 78px;
  left: 84vw;
  bottom: 73vh;
  -webkit-animation: move10 infinite 12s;
  animation: move10 infinite 12s;
}
@-webkit-keyframes move10 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 17vh;
    transform: translate(149px, 0);
    opacity: 0;
  }
}
@keyframes move10 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 17vh;
    transform: translate(149px, 0);
    opacity: 0;
  }
}

.bubble:nth-child(11) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 31px;
  height: 31px;
  left: 77vw;
  bottom: 89vh;
  -webkit-animation: move11 infinite 3s;
  animation: move11 infinite 3s;
}
@-webkit-keyframes move11 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 48vh;
    transform: translate(9px, 0);
    opacity: 0;
  }
}
@keyframes move11 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 48vh;
    transform: translate(9px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(12) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 68px;
  height: 68px;
  left: 90vw;
  bottom: 2vh;
  -webkit-animation: move12 infinite 5s;
  animation: move12 infinite 5s;
}
@-webkit-keyframes move12 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 77vh;
    transform: translate(-14px, 0);
    opacity: 0;
  }
}
@keyframes move12 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 77vh;
    transform: translate(-14px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(13) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 21px;
  height: 21px;
  left: 26vw;
  bottom: 7vh;
  -webkit-animation: move13 infinite 4s;
  animation: move13 infinite 4s;
}
@-webkit-keyframes move13 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 25vh;
    transform: translate(133px, 0);
    opacity: 0;
  }
}
@keyframes move13 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 25vh;
    transform: translate(133px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(14) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 63px;
  height: 63px;
  left: 82vw;
  bottom: 11vh;
  -webkit-animation: move14 infinite 10s;
  animation: move14 infinite 10s;
}
@-webkit-keyframes move14 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 78vh;
    transform: translate(38px, 0);
    opacity: 0;
  }
}
@keyframes move14 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 78vh;
    transform: translate(38px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(15) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 30px;
  height: 30px;
  left: 88vw;
  bottom: 41vh;
  -webkit-animation: move15 infinite 7s;
  animation: move15 infinite 7s;
}
@-webkit-keyframes move15 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 63vh;
    transform: translate(82px, 0);
    opacity: 0;
  }
}
@keyframes move15 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 63vh;
    transform: translate(82px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(16) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 97px;
  height: 97px;
  left: 99vw;
  bottom: 74vh;
  -webkit-animation: move16 infinite 13s;
  animation: move16 infinite 13s;
}
@-webkit-keyframes move16 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 30vh;
    transform: translate(108px, 0);
    opacity: 0;
  }
}
@keyframes move16 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 30vh;
    transform: translate(108px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(17) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 43px;
  height: 43px;
  left: 9vw;
  bottom: 49vh;
  -webkit-animation: move17 infinite 14s;
  animation: move17 infinite 14s;
}
@-webkit-keyframes move17 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 11vh;
    transform: translate(139px, 0);
    opacity: 0;
  }
}
@keyframes move17 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 11vh;
    transform: translate(139px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(18) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 19px;
  height: 19px;
  left: 15vw;
  bottom: 59vh;
  -webkit-animation: move18 infinite 7s;
  animation: move18 infinite 7s;
}
@-webkit-keyframes move18 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 16vh;
    transform: translate(-18px, 0);
    opacity: 0;
  }
}
@keyframes move18 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 16vh;
    transform: translate(-18px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(19) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 57px;
  height: 57px;
  left: 26vw;
  bottom: 78vh;
  -webkit-animation: move19 infinite 6s;
  animation: move19 infinite 6s;
}
@-webkit-keyframes move19 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 55vh;
    transform: translate(59px, 0);
    opacity: 0;
  }
}
@keyframes move19 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 55vh;
    transform: translate(59px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(20) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 47px;
  height: 47px;
  left: 56vw;
  bottom: 35vh;
  -webkit-animation: move20 infinite 14s;
  animation: move20 infinite 14s;
}
@-webkit-keyframes move20 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 28vh;
    transform: translate(142px, 0);
    opacity: 0;
  }
}
@keyframes move20 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 28vh;
    transform: translate(142px, 0);
    opacity: 0;
  }
}

.bubble:nth-child(21) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 52px;
  height: 52px;
  left: 90vw;
  bottom: 94vh;
  -webkit-animation: move21 infinite 14s;
  animation: move21 infinite 14s;
}
@-webkit-keyframes move21 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 37vh;
    transform: translate(-92px, 0);
    opacity: 0;
  }
}
@keyframes move21 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 37vh;
    transform: translate(-92px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(22) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 39px;
  height: 39px;
  left: 3vw;
  bottom: 53vh;
  -webkit-animation: move22 infinite 12s;
  animation: move22 infinite 12s;
}
@-webkit-keyframes move22 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 51vh;
    transform: translate(122px, 0);
    opacity: 0;
  }
}
@keyframes move22 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 51vh;
    transform: translate(122px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(23) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 58px;
  height: 58px;
  left: 82vw;
  bottom: 3vh;
  -webkit-animation: move23 infinite 9s;
  animation: move23 infinite 9s;
}
@-webkit-keyframes move23 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 86vh;
    transform: translate(125px, 0);
    opacity: 0;
  }
}
@keyframes move23 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 86vh;
    transform: translate(125px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(24) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 90px;
  height: 90px;
  left: 31vw;
  bottom: 84vh;
  -webkit-animation: move24 infinite 5s;
  animation: move24 infinite 5s;
}
@-webkit-keyframes move24 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 68vh;
    transform: translate(74px, 0);
    opacity: 0;
  }
}
@keyframes move24 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 68vh;
    transform: translate(74px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(25) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 56px;
  height: 56px;
  left: 51vw;
  bottom: 22vh;
  -webkit-animation: move25 infinite 9s;
  animation: move25 infinite 9s;
}
@-webkit-keyframes move25 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 51vh;
    transform: translate(31px, 0);
    opacity: 0;
  }
}
@keyframes move25 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 51vh;
    transform: translate(31px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(26) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 94px;
  height: 94px;
  left: 32vw;
  bottom: 86vh;
  -webkit-animation: move26 infinite 13s;
  animation: move26 infinite 13s;
}
@-webkit-keyframes move26 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 51vh;
    transform: translate(9px, 0);
    opacity: 0;
  }
}
@keyframes move26 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 51vh;
    transform: translate(9px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(27) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 11px;
  height: 11px;
  left: 90vw;
  bottom: 66vh;
  -webkit-animation: move27 infinite 4s;
  animation: move27 infinite 4s;
}
@-webkit-keyframes move27 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 51vh;
    transform: translate(178px, 0);
    opacity: 0;
  }
}
@keyframes move27 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 51vh;
    transform: translate(178px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(28) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 38px;
  height: 38px;
  left: 44vw;
  bottom: 84vh;
  -webkit-animation: move28 infinite 10s;
  animation: move28 infinite 10s;
}
@-webkit-keyframes move28 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 70vh;
    transform: translate(-26px, 0);
    opacity: 0;
  }
}
@keyframes move28 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 70vh;
    transform: translate(-26px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(29) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 7px;
  height: 7px;
  left: 65vw;
  bottom: 18vh;
  -webkit-animation: move29 infinite 5s;
  animation: move29 infinite 5s;
}
@-webkit-keyframes move29 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 89vh;
    transform: translate(166px, 0);
    opacity: 0;
  }
}
@keyframes move29 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 89vh;
    transform: translate(166px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(30) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 20px;
  height: 20px;
  left: 31vw;
  bottom: 48vh;
  -webkit-animation: move30 infinite 4s;
  animation: move30 infinite 4s;
}
@-webkit-keyframes move30 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 66vh;
    transform: translate(-9px, 0);
    opacity: 0;
  }
}
@keyframes move30 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 66vh;
    transform: translate(-9px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(31) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 43px;
  height: 43px;
  left: 17vw;
  bottom: 2vh;
  -webkit-animation: move31 infinite 14s;
  animation: move31 infinite 14s;
}
@-webkit-keyframes move31 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 28vh;
    transform: translate(22px, 0);
    opacity: 0;
  }
}
@keyframes move31 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 28vh;
    transform: translate(22px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(32) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 79px;
  height: 79px;
  left: 58vw;
  bottom: 63vh;
  -webkit-animation: move32 infinite 6s;
  animation: move32 infinite 6s;
}
@-webkit-keyframes move32 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 49vh;
    transform: translate(24px, 0);
    opacity: 0;
  }
}
@keyframes move32 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 49vh;
    transform: translate(24px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(33) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 62px;
  height: 62px;
  left: 43vw;
  bottom: 22vh;
  -webkit-animation: move33 infinite 6s;
  animation: move33 infinite 6s;
}
@-webkit-keyframes move33 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 17vh;
    transform: translate(119px, 0);
    opacity: 0;
  }
}
@keyframes move33 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 17vh;
    transform: translate(119px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(34) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 42px;
  height: 42px;
  left: 68vw;
  bottom: 62vh;
  -webkit-animation: move34 infinite 7s;
  animation: move34 infinite 7s;
}
@-webkit-keyframes move34 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 2vh;
    transform: translate(-45px, 0);
    opacity: 0;
  }
}
@keyframes move34 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 2vh;
    transform: translate(-45px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(35) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 95px;
  height: 95px;
  left: 25vw;
  bottom: 94vh;
  -webkit-animation: move35 infinite 5s;
  animation: move35 infinite 5s;
}
@-webkit-keyframes move35 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 38vh;
    transform: translate(153px, 0);
    opacity: 0;
  }
}
@keyframes move35 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 38vh;
    transform: translate(153px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(36) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 47px;
  height: 47px;
  left: 98vw;
  bottom: 1vh;
  -webkit-animation: move36 infinite 7s;
  animation: move36 infinite 7s;
}
@-webkit-keyframes move36 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 27vh;
    transform: translate(8px, 0);
    opacity: 0;
  }
}
@keyframes move36 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 27vh;
    transform: translate(8px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(37) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 95px;
  height: 95px;
  left: 62vw;
  bottom: 6vh;
  -webkit-animation: move37 infinite 5s;
  animation: move37 infinite 5s;
}
@-webkit-keyframes move37 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 53vh;
    transform: translate(-48px, 0);
    opacity: 0;
  }
}
@keyframes move37 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 53vh;
    transform: translate(-48px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(38) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 10px;
  height: 10px;
  left: 26vw;
  bottom: 8vh;
  -webkit-animation: move38 infinite 5s;
  animation: move38 infinite 5s;
}
@-webkit-keyframes move38 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 76vh;
    transform: translate(114px, 0);
    opacity: 0;
  }
}
@keyframes move38 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 76vh;
    transform: translate(114px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(39) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 73px;
  height: 73px;
  left: 95vw;
  bottom: 10vh;
  -webkit-animation: move39 infinite 10s;
  animation: move39 infinite 10s;
}
@-webkit-keyframes move39 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 10vh;
    transform: translate(-83px, 0);
    opacity: 0;
  }
}
@keyframes move39 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 10vh;
    transform: translate(-83px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(40) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 43px;
  height: 43px;
  left: 1vw;
  bottom: 100vh;
  -webkit-animation: move40 infinite 7s;
  animation: move40 infinite 7s;
}
@-webkit-keyframes move40 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 12vh;
    transform: translate(14px, 0);
    opacity: 0;
  }
}
@keyframes move40 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 12vh;
    transform: translate(14px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(41) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 35px;
  height: 35px;
  left: 42vw;
  bottom: 39vh;
  -webkit-animation: move41 infinite 5s;
  animation: move41 infinite 5s;
}
@-webkit-keyframes move41 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 65vh;
    transform: translate(144px, 0);
    opacity: 0;
  }
}
@keyframes move41 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 65vh;
    transform: translate(144px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(42) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 82px;
  height: 82px;
  left: 74vw;
  bottom: 3vh;
  -webkit-animation: move42 infinite 13s;
  animation: move42 infinite 13s;
}
@-webkit-keyframes move42 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 0vh;
    transform: translate(-99px, 0);
    opacity: 0;
  }
}
@keyframes move42 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 0vh;
    transform: translate(-99px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(43) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 81px;
  height: 81px;
  left: 86vw;
  bottom: 16vh;
  -webkit-animation: move43 infinite 5s;
  animation: move43 infinite 5s;
}
@-webkit-keyframes move43 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 87vh;
    transform: translate(30px, 0);
    opacity: 0;
  }
}
@keyframes move43 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 87vh;
    transform: translate(30px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(44) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 26px;
  height: 26px;
  left: 64vw;
  bottom: 71vh;
  -webkit-animation: move44 infinite 15s;
  animation: move44 infinite 15s;
}
@-webkit-keyframes move44 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 94vh;
    transform: translate(104px, 0);
    opacity: 0;
  }
}
@keyframes move44 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 94vh;
    transform: translate(104px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(45) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 45px;
  height: 45px;
  left: 22vw;
  bottom: 16vh;
  -webkit-animation: move45 infinite 3s;
  animation: move45 infinite 3s;
}
@-webkit-keyframes move45 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 96vh;
    transform: translate(154px, 0);
    opacity: 0;
  }
}
@keyframes move45 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 96vh;
    transform: translate(154px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(46) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 9px;
  height: 9px;
  left: 21vw;
  bottom: 33vh;
  -webkit-animation: move46 infinite 4s;
  animation: move46 infinite 4s;
}
@-webkit-keyframes move46 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 27vh;
    transform: translate(169px, 0);
    opacity: 0;
  }
}
@keyframes move46 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 27vh;
    transform: translate(169px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(47) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 71px;
  height: 71px;
  left: 55vw;
  bottom: 68vh;
  -webkit-animation: move47 infinite 15s;
  animation: move47 infinite 15s;
}
@-webkit-keyframes move47 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 94vh;
    transform: translate(-62px, 0);
    opacity: 0;
  }
}
@keyframes move47 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 94vh;
    transform: translate(-62px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(48) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 95px;
  height: 95px;
  left: 74vw;
  bottom: 82vh;
  -webkit-animation: move48 infinite 13s;
  animation: move48 infinite 13s;
}
@-webkit-keyframes move48 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 15vh;
    transform: translate(93px, 0);
    opacity: 0;
  }
}
@keyframes move48 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 15vh;
    transform: translate(93px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(49) {
  background: radial-gradient(
    ellipse at center,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 44px;
  height: 44px;
  left: 99vw;
  bottom: 32vh;
  -webkit-animation: move49 infinite 5s;
  animation: move49 infinite 5s;
}
@-webkit-keyframes move49 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 16vh;
    transform: translate(130px, 0);
    opacity: 0;
  }
}
@keyframes move49 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 16vh;
    transform: translate(130px, 0);
    opacity: 0;
  }
}
.bubble:nth-child(50) {
  background: radial-gradient(
    ellipse at top right,
    rgb(221, 221, 221) 0%,
    rgb(130, 130, 130) 46%,
    rgb(37, 37, 37) 100%
  );
  width: 99px;
  height: 99px;
  left: 62vw;
  bottom: 96vh;
  -webkit-animation: move50 infinite 8s;
  animation: move50 infinite 8s;
}
@-webkit-keyframes move50 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 61vh;
    transform: translate(-31px, 0);
    opacity: 0;
  }
}
@keyframes move50 {
  0% {
    bottom: -100px;
  }
  100% {
    bottom: 61vh;
    transform: translate(-31px, 0);
    opacity: 0;
  }
}
</style>
