<template lang="html">
  <div class="content">
    <Store></Store>
  </div>
</template>
<script>
import Store from "./Store.vue";
export default {
  components: {
    Store,
  },
};
</script>
<style></style>
