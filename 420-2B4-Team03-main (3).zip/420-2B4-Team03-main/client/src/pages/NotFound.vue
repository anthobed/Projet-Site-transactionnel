<template lang="html">
  <section>
    <h2>Oups! Maybe You drink to much beer :(</h2>
    <router-link (to="/" )>Get back on road ! </router-link>
  </section>
</template>

<script>
export default {};
</script>

<style scoped></style>
