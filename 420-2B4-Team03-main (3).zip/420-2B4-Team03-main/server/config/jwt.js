const JTW_SECRET = "e7d28345-49c3-408b-b09f-22c0270cd0f6"

module.exports = JTW_SECRET